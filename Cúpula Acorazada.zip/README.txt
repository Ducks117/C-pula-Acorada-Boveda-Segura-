Gracias por descargar el código. Att3 : 4CheinMrDucks.

para poder realizar uso del código necesitaremos varios archivos todos estos se encuentran en la carpeta que descargaste.

pasos

1. Instalar el dotnet-sdk-10.0.041. en Caso de no Tener en Windows   
2. Darle Clic derecha en cualquier parte de la carpeta para poder abrir el terminar desde el clic derecho.
3. Escribir en el terminal "dotnet run".
4. Asignarle la Contraseña Maestra.
5. Darle uso.







Link del dotnet SDK 10.0.401 --- https://dotnet.microsoft.com/es-es/download/dotnet/thank-you/sdk-10.0.401-windows-x64-installer