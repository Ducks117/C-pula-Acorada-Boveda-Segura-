﻿using System.Security.Cryptography;
using System.Text;
using Microsoft.Data.Sqlite;

class Program
{
    static string dbPath = "boveda.db";
    static byte[]? masterKey = null;

    static void Main()
    {
        InicializarBaseDatos();

        Console.WriteLine("=== BÓVEDA DE CONTRASEÑAS ===\n");

        if (!Autenticar())
        {
            Console.WriteLine("No se pudo autenticar. Saliendo...");
            return;
        }

        while (true)
        {
            Console.WriteLine("\n--- MENÚ ---");
            Console.WriteLine("1. Agregar credencial");
            Console.WriteLine("2. Listar credenciales");
            Console.WriteLine("3. Ver / Descifrar una contraseña");
            Console.WriteLine("4. Editar una credencial");
            Console.WriteLine("5. Eliminar una credencial");
            Console.WriteLine("6. Salir");
            Console.Write("Opción: ");
            string? opcion = Console.ReadLine();

            switch (opcion)
            {
                case "1": AgregarCredencial(); break;
                case "2": ListarCredenciales(); break;
                case "3": DescifrarCredencial(); break;
                case "4": EditarCredencial(); break;
                case "5": EliminarCredencial(); break;
                case "6": return;
                default: Console.WriteLine("Opción inválida"); break;
            }
        }
    }

    // ==================== AUTENTICACIÓN ====================
    static bool Autenticar()
    {
        if (!ExisteMasterPassword())
        {
            Console.WriteLine("Primera ejecución. Configure su contraseña maestra:");
            Console.Write("Nueva contraseña maestra: ");
            string nueva = LeerPasswordOculto();
            Console.Write("Confirmar: ");
            string confirmar = LeerPasswordOculto();

            if (nueva != confirmar || string.IsNullOrWhiteSpace(nueva))
            {
                Console.WriteLine("Las contraseñas no coinciden.");
                return false;
            }

            GuardarMasterPassword(nueva);
            Console.WriteLine("Contraseña maestra configurada correctamente.\n");
        }

        Console.Write("Ingrese la contraseña maestra: ");
        string password = LeerPasswordOculto();

        if (ValidarMasterPassword(password))
        {
            masterKey = DerivarClave(password, ObtenerSalt());
            Console.WriteLine("Acceso concedido.\n");
            return true;
        }

        Console.WriteLine("Contraseña maestra incorrecta.");
        return false;
    }

    // Pide la contraseña maestra otra vez (para operaciones sensibles)
    static bool VerificarMasterPasswordNuevamente()
    {
        Console.Write("Ingrese la contraseña maestra para continuar: ");
        string password = LeerPasswordOculto();

        if (ValidarMasterPassword(password))
        {
            masterKey = DerivarClave(password, ObtenerSalt());
            return true;
        }

        Console.WriteLine("Contraseña maestra incorrecta. Operación cancelada.");
        return false;
    }

    // ==================== CIFRADO ====================
    static (byte[] ciphertext, byte[] nonce, byte[] tag) Cifrar(string textoPlano)
    {
        byte[] plaintext = Encoding.UTF8.GetBytes(textoPlano);
        byte[] nonce = new byte[12];
        RandomNumberGenerator.Fill(nonce);

        byte[] ciphertext = new byte[plaintext.Length];
        byte[] tag = new byte[16];

        using var aes = new AesGcm(masterKey!, tag.Length);
        aes.Encrypt(nonce, plaintext, ciphertext, tag);

        return (ciphertext, nonce, tag);
    }

    static string? Descifrar(byte[] ciphertext, byte[] nonce, byte[] tag)
    {
        try
        {
            byte[] plaintext = new byte[ciphertext.Length];
            using var aes = new AesGcm(masterKey!, tag.Length);
            aes.Decrypt(nonce, ciphertext, tag, plaintext);
            return Encoding.UTF8.GetString(plaintext);
        }
        catch (CryptographicException)
        {
            return null;
        }
    }

    static byte[] DerivarClave(string password, byte[] salt)
    {
        return Rfc2898DeriveBytes.Pbkdf2(
            password,
            salt,
            100_000,
            HashAlgorithmName.SHA256,
            32);
    }

    // ==================== BASE DE DATOS ====================
    static void InicializarBaseDatos()
    {
        using var connection = new SqliteConnection($"Data Source={dbPath}");
        connection.Open();

        var cmd = connection.CreateCommand();
        cmd.CommandText = @"
            CREATE TABLE IF NOT EXISTS config (
                id INTEGER PRIMARY KEY,
                salt BLOB NOT NULL,
                verificador BLOB NOT NULL
            );

            CREATE TABLE IF NOT EXISTS credenciales (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                servicio TEXT NOT NULL,
                usuario TEXT NOT NULL,
                ciphertext BLOB NOT NULL,
                nonce BLOB NOT NULL,
                tag BLOB NOT NULL
            );";
        cmd.ExecuteNonQuery();
    }

    static bool ExisteMasterPassword()
    {
        using var connection = new SqliteConnection($"Data Source={dbPath}");
        connection.Open();
        var cmd = connection.CreateCommand();
        cmd.CommandText = "SELECT COUNT(*) FROM config";
        return Convert.ToInt32(cmd.ExecuteScalar()) > 0;
    }

    static void GuardarMasterPassword(string password)
    {
        byte[] salt = new byte[16];
        RandomNumberGenerator.Fill(salt);

        byte[] key = DerivarClave(password, salt);

        using var aes = new AesGcm(key, 16);
        byte[] nonce = new byte[12];
        RandomNumberGenerator.Fill(nonce);
        byte[] plaintext = Encoding.UTF8.GetBytes("BOVEDA_OK");
        byte[] ciphertext = new byte[plaintext.Length];
        byte[] tag = new byte[16];
        aes.Encrypt(nonce, plaintext, ciphertext, tag);

        byte[] verificador = new byte[nonce.Length + tag.Length + ciphertext.Length];
        Buffer.BlockCopy(nonce, 0, verificador, 0, nonce.Length);
        Buffer.BlockCopy(tag, 0, verificador, nonce.Length, tag.Length);
        Buffer.BlockCopy(ciphertext, 0, verificador, nonce.Length + tag.Length, ciphertext.Length);

        using var connection = new SqliteConnection($"Data Source={dbPath}");
        connection.Open();
        var cmd = connection.CreateCommand();
        cmd.CommandText = "INSERT INTO config (id, salt, verificador) VALUES (1, $salt, $verificador)";
        cmd.Parameters.AddWithValue("$salt", salt);
        cmd.Parameters.AddWithValue("$verificador", verificador);
        cmd.ExecuteNonQuery();
    }

    static bool ValidarMasterPassword(string password)
    {
        using var connection = new SqliteConnection($"Data Source={dbPath}");
        connection.Open();
        var cmd = connection.CreateCommand();
        cmd.CommandText = "SELECT salt, verificador FROM config WHERE id = 1";
        using var reader = cmd.ExecuteReader();
        if (!reader.Read()) return false;

        byte[] salt = (byte[])reader["salt"];
        byte[] verificador = (byte[])reader["verificador"];

        byte[] key = DerivarClave(password, salt);

        try
        {
            byte[] nonce = new byte[12];
            byte[] tag = new byte[16];
            byte[] ciphertext = new byte[verificador.Length - 28];

            Buffer.BlockCopy(verificador, 0, nonce, 0, 12);
            Buffer.BlockCopy(verificador, 12, tag, 0, 16);
            Buffer.BlockCopy(verificador, 28, ciphertext, 0, ciphertext.Length);

            using var aes = new AesGcm(key, 16);
            byte[] plaintext = new byte[ciphertext.Length];
            aes.Decrypt(nonce, ciphertext, tag, plaintext);

            return Encoding.UTF8.GetString(plaintext) == "BOVEDA_OK";
        }
        catch
        {
            return false;
        }
    }

    static byte[] ObtenerSalt()
    {
        using var connection = new SqliteConnection($"Data Source={dbPath}");
        connection.Open();
        var cmd = connection.CreateCommand();
        cmd.CommandText = "SELECT salt FROM config WHERE id = 1";
        return (byte[])cmd.ExecuteScalar()!;
    }

    // ==================== OPERACIONES ====================
    static void AgregarCredencial()
    {
        Console.Write("Servicio (ej: Gmail): ");
        string servicio = Console.ReadLine() ?? "";
        Console.Write("Usuario: ");
        string usuario = Console.ReadLine() ?? "";
        Console.Write("Contraseña: ");
        string password = LeerPasswordOculto();

        var (ciphertext, nonce, tag) = Cifrar(password);

        using var connection = new SqliteConnection($"Data Source={dbPath}");
        connection.Open();
        var cmd = connection.CreateCommand();
        cmd.CommandText = @"
            INSERT INTO credenciales (servicio, usuario, ciphertext, nonce, tag)
            VALUES ($servicio, $usuario, $ciphertext, $nonce, $tag)";
        cmd.Parameters.AddWithValue("$servicio", servicio);
        cmd.Parameters.AddWithValue("$usuario", usuario);
        cmd.Parameters.AddWithValue("$ciphertext", ciphertext);
        cmd.Parameters.AddWithValue("$nonce", nonce);
        cmd.Parameters.AddWithValue("$tag", tag);
        cmd.ExecuteNonQuery();

        Console.WriteLine("Credencial guardada correctamente (cifrada).");
    }

    static void ListarCredenciales()
    {
        using var connection = new SqliteConnection($"Data Source={dbPath}");
        connection.Open();
        var cmd = connection.CreateCommand();
        cmd.CommandText = "SELECT id, servicio, usuario FROM credenciales";
        using var reader = cmd.ExecuteReader();

        Console.WriteLine("\nID | Servicio                    | Usuario");
        Console.WriteLine("-----------------------------------------------");
        while (reader.Read())
        {
            Console.WriteLine($"{reader["id"],-3}| {reader["servicio"],-27}| {reader["usuario"]}");
        }
    }

    static void DescifrarCredencial()
    {
        // Ahora SÍ pide la contraseña maestra cada vez
        if (!VerificarMasterPasswordNuevamente()) return;

        ListarCredenciales();
        Console.Write("\nIngrese el ID de la credencial: ");
        if (!int.TryParse(Console.ReadLine(), out int id))
        {
            Console.WriteLine("ID inválido.");
            return;
        }

        using var connection = new SqliteConnection($"Data Source={dbPath}");
        connection.Open();
        var cmd = connection.CreateCommand();
        cmd.CommandText = "SELECT ciphertext, nonce, tag FROM credenciales WHERE id = $id";
        cmd.Parameters.AddWithValue("$id", id);

        using var reader = cmd.ExecuteReader();
        if (!reader.Read())
        {
            Console.WriteLine("Credencial no encontrada.");
            return;
        }

        byte[] ciphertext = (byte[])reader["ciphertext"];
        byte[] nonce = (byte[])reader["nonce"];
        byte[] tag = (byte[])reader["tag"];

        string? password = Descifrar(ciphertext, nonce, tag);

        if (password != null)
            Console.WriteLine($"\n>>> Contraseña descifrada: {password}");
        else
            Console.WriteLine("\n>>> Error: no se pudo descifrar.");
    }

    static void EditarCredencial()
    {
        if (!VerificarMasterPasswordNuevamente()) return;

        ListarCredenciales();
        Console.Write("\nIngrese el ID de la credencial a editar: ");
        if (!int.TryParse(Console.ReadLine(), out int id))
        {
            Console.WriteLine("ID inválido.");
            return;
        }

        // Verificar que exista
        using (var connection = new SqliteConnection($"Data Source={dbPath}"))
        {
            connection.Open();
            var check = connection.CreateCommand();
            check.CommandText = "SELECT COUNT(*) FROM credenciales WHERE id = $id";
            check.Parameters.AddWithValue("$id", id);
            if (Convert.ToInt32(check.ExecuteScalar()) == 0)
            {
                Console.WriteLine("Credencial no encontrada.");
                return;
            }
        }

        Console.Write("Nuevo servicio: ");
        string servicio = Console.ReadLine() ?? "";
        Console.Write("Nuevo usuario: ");
        string usuario = Console.ReadLine() ?? "";
        Console.Write("Nueva contraseña: ");
        string password = LeerPasswordOculto();

        var (ciphertext, nonce, tag) = Cifrar(password);

        using var conn = new SqliteConnection($"Data Source={dbPath}");
        conn.Open();
        var cmd = conn.CreateCommand();
        cmd.CommandText = @"
            UPDATE credenciales 
            SET servicio = $servicio, usuario = $usuario, 
                ciphertext = $ciphertext, nonce = $nonce, tag = $tag
            WHERE id = $id";
        cmd.Parameters.AddWithValue("$servicio", servicio);
        cmd.Parameters.AddWithValue("$usuario", usuario);
        cmd.Parameters.AddWithValue("$ciphertext", ciphertext);
        cmd.Parameters.AddWithValue("$nonce", nonce);
        cmd.Parameters.AddWithValue("$tag", tag);
        cmd.Parameters.AddWithValue("$id", id);
        cmd.ExecuteNonQuery();

        Console.WriteLine("Credencial actualizada correctamente.");
    }

    static void EliminarCredencial()
    {
        if (!VerificarMasterPasswordNuevamente()) return;

        ListarCredenciales();
        Console.Write("\nIngrese el ID de la credencial a eliminar: ");
        if (!int.TryParse(Console.ReadLine(), out int id))
        {
            Console.WriteLine("ID inválido.");
            return;
        }

        using var connection = new SqliteConnection($"Data Source={dbPath}");
        connection.Open();
        var cmd = connection.CreateCommand();
        cmd.CommandText = "DELETE FROM credenciales WHERE id = $id";
        cmd.Parameters.AddWithValue("$id", id);
        int filas = cmd.ExecuteNonQuery();

        if (filas > 0)
            Console.WriteLine("Credencial eliminada correctamente.");
        else
            Console.WriteLine("No se encontró la credencial.");
    }

    static string LeerPasswordOculto()
    {
        var sb = new StringBuilder();
        while (true)
        {
            var key = Console.ReadKey(true);
            if (key.Key == ConsoleKey.Enter) break;
            if (key.Key == ConsoleKey.Backspace && sb.Length > 0)
            {
                sb.Length--;
                Console.Write("\b \b");
            }
            else if (!char.IsControl(key.KeyChar))
            {
                sb.Append(key.KeyChar);
                Console.Write("*");
            }
        }
        Console.WriteLine();
        return sb.ToString();
    }
}